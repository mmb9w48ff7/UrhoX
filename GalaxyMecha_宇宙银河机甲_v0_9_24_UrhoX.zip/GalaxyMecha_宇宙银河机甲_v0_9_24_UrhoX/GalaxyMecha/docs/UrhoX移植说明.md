# 宇宙银河机甲 · UrhoX（TapTap 嵌入式容器）移植说明（Lua 版 v1）

> 结论先说：UrhoX 是 Lua 5.4 引擎，**不能直接运行网页版**，所以这一版是把游戏用 Lua 重写进 UrhoX 工程（入口 `scripts/main.lua`）。
> 这份代码**只在“模拟引擎”里跑通过**（见文末），**没有在真正的 UrhoX 编辑器 / 真机里运行过**，请务必先在编辑器里试跑并按“风险清单”逐项确认。

## 一、已移植的内容（Lua 版 v1）

| 模块 | 文件 | 说明 |
|---|---|---|
| 玩法数据 | `scripts/cosmic/Data.lua` | 由 `tools/export_cosmic_data.py` 从网页版导出：6 台机甲、6 位驾驶员、3 章、20 种技能形态、6 种元素、进化表、金色特效、召唤概率、14 种敌人（含 5 种新敌人与 3 个首领）等 |
| 体素模型 | `scripts/voxeldata/models/*.lua` | 70 个整机 / 敌人 / 特效模型 + **60 个机甲分件模型**（头、大臂、小臂、大腿、小腿、躯干）；`scripts/voxeldata/Rigs.lua` 为关节 / 枪口 / 喷口挂点 |
| 机甲与动画 | `scripts/cosmic/Mech.lua` | 分件节点树 + 姿态动画：前倾、腿部后收、躯干扭转、头部转向、手臂（大臂 + 小臂）瞄准、后坐、技能姿态 |
| 战斗 | `scripts/cosmic/Run.lua` | 水平面飞行、自动瞄准、6 种主武器、6 个机甲技能、氮气（每台不同）、氮气联动、14 种敌人 AI（冲撞 / 狙击 / 自爆 / 瞬移 / 震地 / 盾卫格挡 / 裂变）、首领三阶段 + 激光、卡牌（追踪导弹 / 环绕刃 / 冲击波 / 落雷 / 光束 / 扇形弹幕及其派生形态）、元素反应（碎冰 / 爆燃 / 融蚀 / 麻痹 / 湮灭）、升级选卡 + 进化 + 刷新 / 跳过、危险等级 1~10、无尽模式、结算 |
| 界面 | `scripts/cosmic/UI.lua` `Screens.lua` | NanoVG 立即模式：机库（选机甲 / 章节 / 危险等级 / 出击 / 无尽 / 召唤 / 设置）、战斗 HUD（摇杆、技能、氮气、耐久、经验、首领血条、伤害数字）、升级选卡、暂停、结算；触控 + 鼠标 + 键盘（WASD / 方向键，空格 = 氮气，E = 技能） |
| 存档 | `scripts/cosmic/Save.lua` | JSON，写入引擎的项目 + 用户隔离目录 |
| TapTap SDK | `scripts/cosmic/Sdk.lua` | `sdk:ShowRewardVideoAd`（只有 `result.success` 才发奖励；SDK 不可用时不弹任何“模拟广告”、不发奖励）、`sdk:GetNativeExitMenuRect`（HUD 避让退出按钮） |
| 音频 | `scripts/cosmic/Sound.lua` + `assets/Sounds/*.ogg` | 19 个 ogg（13 音效 + 3 BGM 等），资源路径 `Sounds/xxx.ogg`（按文档约定） |

## 二、**没有**移植的内容（仍只在网页版里）

- 工坊：技能卡牌收集（1080 张）、卡牌升级 / 装备、天赋芯片。Lua 版战斗里默认装备 3 张白色卡牌（追踪导弹 / 冲击波 / 环绕刃）。
- 驾驶员系统（支援技能、被动、专属匹配加成）；召唤只做了“抽机甲”的简化版（星源 10，含保底）。
- 每日挑战、7 日登录、成就、每日任务、新手引导、关于与合规页。
- 技能形态“地雷 / 回旋镖”及其派生形态（Lua 版不会抽到）。
- 3D 垂直飞行（Lua 版在水平面上飞行，敌人在上下 ±6 米内）、视线通道（粒子被镜头遮挡规则）、辉光细节与大部分特效的精细度（用体素小方块粒子简化）。

## 三、怎么在 UrhoX 里运行

1. 以本工程根目录作为 UrhoX 项目，入口 `scripts/main.lua`（旧版“陨星银河”保留在 `scripts/main_legacy_xingyun.lua` + `scripts/game/`，不再使用）。
2. 音频：把 `assets/Sounds/` 放到项目资源目录（路径 `Sounds/*.ogg`）。字体使用引擎自带 `Fonts/MiSans-Bold.ttf`（文档里只明确写了 MiSans-Regular，若 Bold 不存在，`UI.Init` 会回退到 Regular）。
3. 模型：`scripts/voxeldata/` 已是生成结果；改模型请改 `tools/models_*.py`，运行 `python3 tools/build_voxels.py` 重新生成。
4. 玩法数据：改了网页版数值后，运行 `python3 tools/export_cosmic_data.py` 重新导出 `Data.lua`（需要 playwright + chromium + node）。

## 四、已做的验证 / 没做的验证

已验证（模拟引擎 `tools/mock_cosmic_test.lua`，`python3 tools/run_mock_test.py` 可复现）：
- 全部 Lua 文件语法正确；启动 -> 机库 -> 点击出击 -> 6 台机甲各战斗 25 秒（含技能、氮气、升级选择）-> 刷出首领并走完三阶段 -> 结算 -> 返回机库 -> 无尽 + 危险等级 -> 升级 / 暂停 / 结算界面绘制 -> 召唤保底，全程没有运行时错误。

**没有验证（需要你在 UrhoX 里确认）**：
1. 真实引擎里的 `Quaternion(x, y, z)` 欧拉角约定是否与网页版一致（Lua 版沿用“pitch 正 = 机头向下、yaw 正 = 转向 +X”）；若手臂 / 腿的转向反了，改 `Mech.lua` 里的符号。
2. `node.worldPosition` 读取（枪口位置依赖它）、`Node:Clone()`、`CustomGeometry` 材质在大量粒子下的性能（`Fx.max = 320`，必要时调小）。
3. NanoVG 的 `nvgScale` + 设计分辨率 1920x1080 的触控坐标换算、`input:GetTouch` 的坐标单位（若是归一化坐标，要在 `UI.lua gather()` 里乘屏幕尺寸）。
4. `sdk` 全局在 TapTap 容器里的真实行为；退出按钮区域是否与 HUD 重叠。
5. 音频资源路径 `Sounds/xxx.ogg`；`SoundSource` 播放与自动移除。
6. 性能：手机上的帧率、发热、内存（Lua 版每帧创建 / 销毁大量粒子节点，建议先在真机看帧率，再调粒子数量）。
7. TapTap 上架所需的版号、实名与防沉迷、隐私政策、用户协议、应用图标（512x512）等，仍需你自行准备（见 `docs/TapTap上架与侵权自查.md`）。

## 五、建议的下一步

1. 先在 UrhoX 编辑器里跑起来，对照上面的“没有验证”清单逐项确认，把看到的问题告诉我，我再改。
2. 然后补移植：工坊（卡牌收集 + 装备）、驾驶员、每日挑战 / 登录 / 成就。
3. 最后做真机性能优化与 TapTap 提审材料。
