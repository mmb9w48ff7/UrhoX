-- main.lua：宇宙银河机甲（体素 Q 版机甲割草）—— UrhoX / TapTap 嵌入式容器入口
-- 目录：
--   cosmic/Data.lua      玩法数据（由 tools/export_cosmic_data.py 从网页版导出）
--   cosmic/Run.lua       一局战斗：飞行、机甲技能、敌人 AI、卡牌、升级、首领、结算
--   cosmic/Mech.lua      机甲分件节点树与姿态动画
--   cosmic/UI.lua / Screens.lua   NanoVG 界面（机库、HUD、升级选卡、结算）与触控输入
--   cosmic/Sdk.lua       TapTap SDK（激励视频、退出按钮区域）
--   voxeldata/           由 tools/build_voxels.py 生成的体素模型（含机甲分件与 Rigs.lua 挂点）
-- 旧版（陨星银河，太空贸易玩法）保留在 main_legacy_xingyun.lua + game/，不再使用。
local App = require("cosmic.App")

function Start() App.Start() end
function Stop() App.Stop() end
function HandleUpdate(eventType, eventData) App.Update(eventData["TimeStep"]:GetFloat()) end
function HandleNanoVGRender(eventType, eventData) App.Render() end
