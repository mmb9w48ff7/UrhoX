-- Sound.lua：音效与背景音乐（.ogg）。资源路径 Sounds/*.ogg（由 assets/Sounds 提供）。
local Sound = { enabled = true, music = true }
local nodes_, bgm_, cache_ = nil, nil, {}
local last_ = {}
local GAP = { shoot = 0.09, pop = 0.05, hit = 0.07, crit = 0.1, hurt = 0.15, boom = 0.08, pick = 0.06 }
local VOL = { nitro = 0.75, hit = 0.8, crit = 0.9, shoot = 0.8 }
function Sound.Init(scene)
    nodes_ = scene:CreateChild("Audio")
end
local function get(name)
    local s = cache_[name]
    if s == nil then
        local ok, res = pcall(function() return cache:GetResource("Sound", "Sounds/" .. name .. ".ogg") end)
        s = ok and res or false; cache_[name] = s
    end
    return s
end
function Sound.Sfx(name, now)
    if not Sound.enabled or not nodes_ then return end
    if GAP[name] and last_[name] and now - last_[name] < GAP[name] then return end
    last_[name] = now
    local snd = get("sfx_" .. name); if not snd then return end
    local src = nodes_:CreateComponent("SoundSource")
    src.soundType = SOUND_EFFECT; src.gain = VOL[name] or 1; src.autoRemoveMode = REMOVE_COMPONENT; src:Play(snd)
end
function Sound.Music(name)
    if not nodes_ then return end
    if bgm_ then bgm_:Stop(); bgm_:Remove(); bgm_ = nil end
    if not Sound.music or not name then return end
    local snd = get("bgm_" .. name); if not snd then return end
    snd.looped = true
    bgm_ = nodes_:CreateComponent("SoundSource"); bgm_.soundType = SOUND_MUSIC; bgm_.gain = 0.7; bgm_:Play(snd)
end
return Sound
